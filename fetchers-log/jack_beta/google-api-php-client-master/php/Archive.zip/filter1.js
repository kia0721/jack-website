function Func1(){
    var x = document.getElementById("novice");  
    x.style.opacity = "1";   
    }
    
    function Func2(){
    var x = document.getElementById("novice");  
    x.style.opacity = "0";   
    }
    
    function Func3(){
    var x = document.getElementById("junior");  
    x.style.opacity = "1";   
    }
    
    function Func4(){
    var x = document.getElementById("junior");  
    x.style.opacity = "0";   
    }
    
    function Func5(){
    var x = document.getElementById("master");  
    x.style.opacity = "1";   
    }
    
    function Func6(){
    var x = document.getElementById("master");  
    x.style.opacity = "";   
    }