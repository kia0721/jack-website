

  <?php
  error_reporting(E_ALL);
   ini_set('display_errors',1);
   $servername = '127.0.0.1';
   $username = 'root';
   $password = 'j@ck.2k18@AWS';
   $database ='allan_jack-blog';
   $db = new mysqli($servername, $username, $password, $database);
?>
