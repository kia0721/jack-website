function myFunc1(){
    var x = document.getElementById("description");  
    x.style.opacity = "1";   
    }
    
    function myFunc2(){
    var x = document.getElementById("description");  
    x.style.opacity = "0";   
    }
    
    function myFunc3(){
    var x = document.getElementById("description2");  
    x.style.opacity = "1";   
    }
    
    function myFunc4(){
    var x = document.getElementById("description2");  
    x.style.opacity = "0";   
    }
    
    function myFunc5(){
    var x = document.getElementById("description3");  
    x.style.opacity = "1";   
    }
    
    function myFunc6(){
    var x = document.getElementById("description3");  
    x.style.opacity = "0";   
    }
    
    function myFunc7(){
    var x = document.getElementById("description4");  
    x.style.opacity = "1";   
    }
    
    function myFunc8(){
    var x = document.getElementById("description4");  
    x.style.opacity = "0";   
    }