<?php



$b = 'hello';

test($b);

function test($a) {
echo $a;
// echo "test inside function";

}



?>