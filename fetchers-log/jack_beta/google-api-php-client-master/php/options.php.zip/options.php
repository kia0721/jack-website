<?php

print_r($_POST);
print_r($_FILES);



?>

<?php
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {
    session_unset(); 
    header("Location: login.php");
  }

if (isset($_SESSION['login_user'])) {
echo $_SESSION['login_user'] ;
} else {

    header ("Location:login.php");
  exit();
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>JACK LOG UPLOAD</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="options.css">
  <link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=PT+Sans" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script src="options.js"></script>
 

  
</head>
<body>

<div class="container-fluid">
<div class="row">
<div class="container">
    <div class="boxheader">
        <p class="header">
        Upload <i class="fas fa-file-upload"></i>
        </p>
    </div>
    <div>
    <form name="uploadForm" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
        <p class="text" style="color:#484848; margin-left:10px; margin-top:60px;">Upload File:</p>
        <div style="height:200px; width:200px; margin-top:-70px; margin-left:10px;">
            <input type="file" style="opacity:1; width:200px; height:80px;" name="test">
        </div>
        <button type="submit" name="submit_btn" class="button1 loginbutton" style="margin-top:-30px;" onclick="">Submit
        </button>
    </form>
    
    </div>
</div>

<div class="container" style="margin-left:700px; margin-top:-730px;">
<div class="boxheader">
    <p class="header">
    Edit <i class="fas fa-edit"></i>
    </p>
    </div>
    <div>
    <p class="text" style="color:#484848; margin-left:10px; margin-top:50px;">Replace:</p>
    <select style=" margin-left:10px; margin-top:-10px; position:absolute;">
        <option value="None">None Selected</option>
        <option value="1">Example Fetcher's Log 1</option>
        <option value="2">Example Fetcher's Log 2</option>
        <option value="3">Example Fetcher's  log 3</option>
</select>

<p class="text" style="color:#484848; margin-left:10px; margin-top:50px;">With:</p>
    <select style=" margin-left:10px; margin-top:-10px; position:absolute;" id="pic-changer">
        <option value="http://mlb.mlb.com/tor/schedule/game-categories/images/april_2017_1920x1080.jpg">Example Fetcher's Log 1</option>
        <option value="https://www.smartsheet.com/sites/default/files/weekly-college-schedule-template.jpg"> Example Fetcher's Log 2</option>
        <option>Example Fetcher's  log 3</option>
</select>
    </div>
    <input type="submit" class="button1 loginbutton" style="margin-top:110px;">
    <div id="image-location" style="margin-top:-10px; margin-left:20px;">
    </div>
</div>

</div>
</div>
</div>
</body>

</html>

<?php


// if form is submitted
if(isset($_POST['submit_btn'])) 
{

    $fileExistsFlag = 0; 
    $fileName = $_FILES['test']['name'];

    $link = mysqli_connect("localhost","root","","allan_jack-blog") or die("Error ".mysqli_error($link));

    $query = "SELECT image_title FROM jack_fetcherslog WHERE image_title='$fileName'";	
    $result = $link->query($query) or die("Error : ".mysqli_error($link));
    while($row = mysqli_fetch_array($result)) {
        if($row['filename'] == $fileName) {
            $fileExistsFlag = 1;
        }		
    }

    $quality = 25;
    // $source_url = "/opt/lampp/htdocs/project_status_dashboard/jack_beta/google-api-php-client-master/php/files/";
    $destination_url = "/opt/lampp/htdocs/project_status_dashboard/jack_beta/google-api-php-client-master/php/files/$fileName";


    if($fileExistsFlag == 0) { 
        $target = "/opt/lampp/htdocs/project_status_dashboard/jack_beta/google-api-php-client-master/php/files/temp/";		
        $fileTarget = $target.$fileName;	
        $tempFileName = $_FILES["test"]["tmp_name"];
        // $fileDescription = $_POST['Description'];	
        $result = move_uploaded_file($tempFileName,$fileTarget);

        compressimages($fileTarget, $destination_url, $quality);

        
        if($result) { 
        
            echo "Your file <html><b><i>".$fileName."</i></b></html> has been successfully uploaded";		
            $query = "INSERT INTO jack_fetcherslog(image_id,image_path,image_title) VALUES ('',$destination_url,$fileName)";
            $link->query($query) or die("Error : ".mysqli_error($link));			
        }
        else {			
            echo "Sorry, your file was not uploaded properly. Please try again.";			
        }
        mysqli_close($link);
    }

    else {
        echo "File <html><b><i>".$fileName."</i></b></html> already exists in your folder. Please rename the file and try again.";
        mysqli_close($link);
    }	

}



function compressimages($source_url, $destination_url, $quality) {

 $info = getimagesize($source_url);

  if ($info['mime'] == 'image/jpeg')
        $image = imagecreatefromjpeg($source_url);

  elseif ($info['mime'] == 'image/gif')
        $image = imagecreatefromgif($source_url);

elseif ($info['mime'] == 'image/png')
        $image = imagecreatefrompng($source_url);

  imagejpeg($image, $destination_url, $quality);
return $destination_url;
}

?>



